import json
from flask import Flask, request, make_response

app = Flask(__name__)


@app.route("/findacvs", methods=["post"])
def findCondi():
    j = request.get_data()
    print(j)
    j = j.decode()
    print(j)
    j = json.loads(j)
    print(j)
    rtnPath = make_response(json.dumps(j))
    rtnPath.headers['Access-Control-Allow-Origin'] = '*'
    return rtnPath


app.run(host="0.0.0.0", debug=True, port=5000)
