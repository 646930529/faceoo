var settings = null;
var canvas = document.getElementById("myCanvas");
var upload_box1 = document.getElementById("upload_box1");
var upload_box2 = document.getElementById("upload_box2");
var img_box1 = document.getElementById("result_obj1");
var img_box2 = document.getElementById("result_obj2");
var cpr_box = document.getElementById("cpr_box");
var sim = document.getElementById("cpr_result");
var dataURL1 = null;
var dataURL2 = null;
var img1 = null;
var img2 = null;
$("#fileUp1").change(function eventStart() {
  console.log("上传了" + this.files.length + "个文件");
  let ss = this.files[0]; //获取当前选择的文件对象
  let reader = new FileReader();
  reader.readAsDataURL(ss); // 读出 base64
  reader.onloadend = function() {
    console.log("ok");
    dataURL1 = reader.result; //base64
    upload_box1.src = dataURL1;
	bt1()
  };
});

$("#fileUp2").change(function eventStart() {
  console.log("上传了" + this.files.length + "个文件");
  let ss = this.files[0]; //获取当前选择的文件对象
  let reader = new FileReader();
  reader.readAsDataURL(ss); // 读出 base64
  reader.onloadend = function() {
    console.log("ok");
    dataURL2 = reader.result; //base64
    upload_box2.src = dataURL2;
	bt2()
  };
});

function bt1() {
  dataURL = dataURL1.split(",")[1];
  data = { base64: dataURL };
  $.ajax({
    url: "http://192.168.1.40:5000/getface",
    type: "post",
    dataType: "json",
    data: JSON.stringify(data),
    success: function(response) {
      console.log(response);
      let img = response.base64;
      img_box1.src = "data:image/png;base64," + img;
    }
  });
}

function bt2() {
  dataURL = dataURL2.split(",")[1];
  data = { base64: dataURL };
  $.ajax({
    url: "http://192.168.1.40:5000/getface",
    type: "post",
    dataType: "json",
    data: JSON.stringify(data),
    success: function(response) {
      console.log(response);
      let img = response.base64;
      img_box2.src = "data:image/png;base64," + img;
    }
  });
}

$("#cpr_btn").bind("click", function() {
  debugger;
  pic1 = img_box1.src.split(",")[1];
  pic2 = img_box2.src.split(",")[1];
  data = { a: pic1, b: pic2 };
  $.ajax({
    url: "http://192.168.1.40:5000/faceoo",
    type: "post",
    dataType: "json",
    data: JSON.stringify(data),
    success: function(response) {
      console.log(response);
      sim.innerHTML = response.similarity;
    }
  });
});

