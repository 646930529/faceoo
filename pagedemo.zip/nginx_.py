from flask import Flask, send_file, request
import os
 
app = Flask(__name__)

@app.before_request
def before_request():
	filename = os.getcwd() + request.path
	if os.path.exists(filename):
		return send_file(filename)
	else:
		return ''

app.run(host='0.0.0.0',port=13579)

# http://127.0.0.1:13579/index.html
